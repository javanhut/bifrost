# Hello Carrion

A simple test package for the Carrion programming language and Bifrost package manager.

## Usage

```carrion
import HelloCarrion from "hello-carrion"

HelloCarrion.greet()
HelloCarrion.version()
```

## Features

- Simple greeting functionality
- Version information
- Example of Carrion package structure

## License

MIT License - see LICENSE file for details.